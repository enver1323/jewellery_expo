<?php
return [
    'success' => [
        'create' => ':item was successfully created',
        'update' => ':item was successfully modified',
        'delete' => ':item was successfully deleted',
    ]
];
