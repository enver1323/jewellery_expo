<?php

return [
    'fairInfo' => 'Fair Info',
    'aboutFair' => 'About Fair',
    'forVisitor' => 'For Visitor',
    'forExhibitor' => 'For Exhibitor',
    'exhibitorList' => 'Exhibitor List',
    'forVisitorSteps' => 'Steps for Visitor',
    'productSections' => 'Product Sections',
];
