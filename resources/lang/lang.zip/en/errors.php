<?php
return [
    'whoops' => 'Sorry, something went wrong',
    'countryNF' => 'Country was not found'

];
