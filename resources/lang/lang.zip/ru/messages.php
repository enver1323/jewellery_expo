<?php
return [
    'success' => [
        'create' => ':item был успешно создан',
        'update' => ':item был успешно обновлён',
        'delete' => ':item был успешно удалён',
    ]
];
