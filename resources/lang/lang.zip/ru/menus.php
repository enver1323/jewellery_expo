<?php

return [
    'fairInfo' => 'Информация о выставке',
    'aboutFair' => 'О выставке',
    'forVisitor' => 'Для посетителя',
    'forExhibitor' => 'Для участника',
    'exhibitorList' => 'Список участников',
    'forVisitorSteps' => 'Шаги для Посетителя',
    'productSections' => 'Разделы выставки',
];
